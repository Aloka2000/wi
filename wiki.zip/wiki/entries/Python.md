# Python

Python is a programming language that can be used both for writing **command-line scripts** or building **web applications**.
